import os, json, pathlib, random, string
ROOT = pathlib.Path(__file__).resolve().parents[1]
NIVEIS = [
  ("Fundação","fundacao","assets/css/tema-fundacao.css", {"visualizacao":True,"habitos":True,"recompensas":True,"install":True,"checkin":True}),
  ("Ascensão","ascensao","assets/css/tema-ascensao.css", {"visualizacao":True,"habitos":True,"recompensas":True,"install":True,"checkin":True}),
  ("Domínio","dominio","assets/css/tema-dominio.css", {"visualizacao":True,"habitos":False,"recompensas":True,"install":True,"checkin":True}),
  ("OverPrime","overprime","assets/css/tema-overprime.css", {"visualizacao":True,"habitos":True,"recompensas":True,"install":True,"checkin":True}),
  ("OverLord","overlord","assets/css/tema-overlord.css", {"visualizacao":True,"habitos":True,"recompensas":True,"install":True,"checkin":True}),
  ("Mind Stage","mind","assets/css/tema-overlord.css", {"visualizacao":True,"habitos":True,"recompensas":False,"install":True,"checkin":True}),
  ("Body Stage","body","assets/css/tema-overlord.css", {"visualizacao":False,"habitos":True,"recompensas":False,"install":True,"checkin":True}),
  ("OverCore","overcore","assets/css/tema-overlord.css", {"visualizacao":True,"habitos":True,"recompensas":True,"install":True,"checkin":True}),
]
def randslug(n=5): return ''.join(random.choice(string.ascii_lowercase+string.digits) for _ in range(n))
def main():
  mapa={}
  base_tpl = (ROOT/'nivel'/'nivel-base.html').read_text(encoding='utf-8')
  for (title, data_slug, theme, features) in NIVEIS:
    code = randslug(5); mapa[data_slug]=code; out_name=f"{data_slug}-{code}.html"
    html = base_tpl.replace("{{TITULO_NIVEL}}", title)      .replace("{{ARQUIVO_TEMA}}", theme.split('/')[-1])      .replace("{{SLUG_NIVEL}}", data_slug)      .replace("{{FEATURES}}", json.dumps(features))      .replace("{{MANIFEST}}", f"manifest-{data_slug}.webmanifest")
    (ROOT/'nivel'/out_name).write_text(html, encoding='utf-8')
    manifest = {
      "name": f"EVO360 — {title}", "short_name": f"{title}",
      "start_url": f"./nivel/{out_name}?src=app","scope":"./","display":"standalone",
      "background_color":"#0b0d10","theme_color":"#0b0d10",
      "icons":[{"src":"./assets/img/icons/icon-192.png","sizes":"192x192","type":"image/png"},
               {"src":"./assets/img/icons/icon-512.png","sizes":"512x512","type":"image/png"}]
    }
    (ROOT/f"manifest-{data_slug}.webmanifest").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
  (ROOT/'_private'/'mapa-portais.json').write_text(json.dumps(mapa, indent=2), encoding='utf-8')
  print("Slugs gerados:", mapa)
if __name__=='__main__': main()
